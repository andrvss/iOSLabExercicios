import UIKit

//var list: [String] = ["Marcos", "Leonardo", "Paulo", "Pedro", "Vinicius"]
//
//let name: String = "Paulo"
//
//print(list)
//print(list[2])
//
//print(list.count)
//list.append("Caio")
//
//list.insert("Caio", at: 3)
//print(list)
//
//let filteredList = list.filter({ $0 == "Paulo" })
//print(filteredList)
//
//list[1] = "Matheus"
//print(list)

var listaDeFilmes: [String] = ["Titanic", "Avatar", "Carros", "Velozes e Furiosos", "Vingadores: Ultimato", "John Wick", "Star Wars", "Duna 2", "Harry Potter", "Maze Runner", "Divertidamente"]

print(listaDeFilmes)

listaDeFilmes.insert("Django Livre", at: 3)

print(listaDeFilmes)

listaDeFilmes.remove(at: 4)

print(listaDeFilmes)

//let novosFilmes = ["Era uma Vez em Hollywood", "Coringa"]
//
//let filmesAtualizados = listaDeFilmes += novosFilmes
//print(filmesAtualizados)

//Exemplo de Exercicio 1
//let myConstant = Int("7")

// Exemplo de Exercicio 2
//var needsUpdate = false
//var forceUpdate = true
//if needsUpdate || forceUpdate {
//    print("Updating system...")
//} else if forceUpdate {
//    print("Force updating the system...")
//} else {
//    print("No updates.")
//}





import UIKit

//var name: String? = "Paulo"
// name = nil
//
// if name != nil {
//     let nameTwo: String = name!
//}
//

// 1 - Default Value
//let nameResult: String = name ?? "Maria"
//print(nameResult)

// 2 - If Let

//if let name {
//    print(name)
//}

// 3 - Guard Let

//@MainActor func some() {
//    guard let name else {
//        print("Digite seu nome.")
//        return
//    }
//    print(name)
//}
//some()


let name: String? = "Paulo" //String
let number: Double? = 20.3 //Double
let numberTwo: String? = "20.5" //Float
let age: String = "20" //Int
let gender: Int? = 0 //Bool

// 1
if let name {
    let nameResult: String = name
}

// 2:
let numberResult = number ?? 20.3
//if let numberOneChanged = number {
//    let numberCorrect = numberOneChanged
//    print(numberCorrect) // Precisa imprimir 20.3
//} else {
//    print("Verifica valor é nil.")
//}

// 3:
func some() {
    guard let numberTwo,
          let numberTwoToFloat = Float(numberTwo)
    else {
        return
    }
}
//if let numberTwoChanged = numberTwo {
//    if let newNumberFloat = Float(numberTwo ?? "20.5") {
//        print("Teste para visulizar o valor final.")
//    } else {
//        print("Nào tem valor sendo registrado.")
//    }
//}

// 4:
let ageToInt = Int(age)

let ageToIntDefault = ageToInt ?? 20

//5
let genderToInt = gender ?? 0

